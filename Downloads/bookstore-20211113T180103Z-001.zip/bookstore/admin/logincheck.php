<?php
if (!isset($_SESSION['aloggedin'])) {
  header('location: login.php');
}

 ?>
